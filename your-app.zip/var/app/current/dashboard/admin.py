from django.contrib import admin
from .models import Category, Subcategory, Keyword, Item, Affiliate, AffiliateLink, Order,ItemVariant

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'discount']
    search_fields = ['name']

@admin.register(Subcategory)
class SubcategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'discount']
    search_fields = ['name', 'category__name']

@admin.register(Keyword)
class KeywordAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

class ItemVariantInline(admin.TabularInline):
    model = ItemVariant
    extra = 1

class ItemAdmin(admin.ModelAdmin):
    inlines = [ItemVariantInline]

admin.site.register(Item, ItemAdmin)
admin.site.register(ItemVariant)
@admin.register(Affiliate)
class AffiliateAdmin(admin.ModelAdmin):
    list_display = ['user', 'points']
    search_fields = ['user__username']

@admin.register(AffiliateLink)
class AffiliateLinkAdmin(admin.ModelAdmin):
    list_display = ['affiliate', 'item', 'unique_code', 'created_at']
    search_fields = ['affiliate__user__username', 'item__name', 'unique_code']

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['item', 'affiliate_link', 'user', 'confirmed', 'status', 'created_at', 'region']
    search_fields = ['item__name', 'user__username', 'region']
    list_filter = ['status', 'confirmed', 'region']
