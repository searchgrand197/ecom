# from django.core.management.base import BaseCommand
# from dashboard.models import Category, Subcategory, Item, Order
# from django.contrib.auth.models import User
# from faker import Faker
# import random
# from django.db import models
#
# from datetime import datetime
#
# class Command(BaseCommand):
#     help = 'Generate random users, categories, subcategories, items, and dispatch orders'
#
#     def handle(self, *args, **kwargs):
#         # Initialize Faker
#         fake = Faker()
#
#         # Create random users
#         for _ in range(10):
#             user = User.objects.create_user(
#                 username=fake.user_name(),
#                 email=fake.email(),
#                 password='password123',
#                 first_name=fake.first_name(),
#                 last_name=fake.last_name()
#             )
#             self.stdout.write(self.style.SUCCESS(f'Created user: {user.username}'))
#
#         # Create sample categories
#         categories = [
#             {'name': 'Electronics', 'details': 'All electronic items', 'discount': random.randint(5, 15)},
#             {'name': 'Clothing', 'details': 'Fashion and clothing items', 'discount': random.randint(10, 20)},
#             {'name': 'Home Appliances', 'details': 'Appliances for home use', 'discount': random.randint(3, 10)},
#         ]
#
#         category_objects = []
#         for cat_data in categories:
#             category = Category.objects.create(**cat_data)
#             category_objects.append(category)
#             self.stdout.write(self.style.SUCCESS(f'Created category: {category.name}'))
#
#         # Create sample subcategories
#         subcategories = [
#             {'name': 'Mobile Phones', 'category': category_objects[0], 'details': 'Smartphones and accessories', 'discount': random.randint(5, 10)},
#             {'name': 'Men\'s Fashion', 'category': category_objects[1], 'details': 'Clothing for men', 'discount': random.randint(15, 25)},
#             {'name': 'Kitchen Appliances', 'category': category_objects[2], 'details': 'Appliances for the kitchen', 'discount': random.randint(5, 8)},
#         ]
#
#         subcategory_objects = []
#         for sub_data in subcategories:
#             subcategory = Subcategory.objects.create(**sub_data)
#             subcategory_objects.append(subcategory)
#             self.stdout.write(self.style.SUCCESS(f'Created subcategory: {subcategory.name}'))
#
#         # Create random items
#         for _ in range(10):
#             item = Item.objects.create(
#                 name=fake.word().capitalize(),
#                 subcategory=random.choice(subcategory_objects),
#                 sku=fake.uuid4(),
#                 stock=random.randint(1, 100),
#                 price=round(random.uniform(10.99, 999.99), 2),
#                 discount=random.randint(5, 20),
#                 specification=fake.text(),
#                 last_modified_by=random.choice(User.objects.all())
#             )
#             self.stdout.write(self.style.SUCCESS(f'Created item: {item.name}'))
#
#         # Dispatch orders
#
#
#         self.stdout.write(self.style.SUCCESS('Successfully populated the database with random data'))
from django.core.management.base import BaseCommand
from dashboard.models import Category, Subcategory, Item, Keyword
from django.contrib.auth.models import User
from faker import Faker
import random

class Command(BaseCommand):
    help = 'Generate random users, categories, subcategories, items, and keywords related to mobile phones'

    def handle(self, *args, **kwargs):
        # Initialize Faker
        fake = Faker()

        # Create random users
        for _ in range(10):
            user = User.objects.create_user(
                username=fake.user_name(),
                email=fake.email(),
                password='password123',
                first_name=fake.first_name(),
                last_name=fake.last_name()
            )
            self.stdout.write(self.style.SUCCESS(f'Created user: {user.username}'))

        # Create or get category
        category, created = Category.objects.get_or_create(
            name='Electronics',
            defaults={'details': 'All electronic items', 'discount': random.uniform(5, 15)}
        )
        if created:
            self.stdout.write(self.style.SUCCESS(f'Created category: {category.name}'))
        else:
            self.stdout.write(self.style.SUCCESS(f'Category already exists: {category.name}'))

        # Create or get subcategory
        subcategory, created = Subcategory.objects.get_or_create(
            name='Mobile Phones',
            defaults={'category': category, 'details': 'Smartphones and accessories', 'discount': random.uniform(5, 10)}
        )
        if created:
            self.stdout.write(self.style.SUCCESS(f'Created subcategory: {subcategory.name}'))
        else:
            self.stdout.write(self.style.SUCCESS(f'Subcategory already exists: {subcategory.name}'))

        # Create or get keywords related to mobile phones
        keywords = [
            'Camera', 'RAM', 'Storage', 'Battery', 'Processor', 'Display', '5G', 'Wireless Charging', 'Dual SIM', 'Fingerprint Sensor'
        ]

        keyword_objects = []
        for keyword_name in keywords:
            keyword, created = Keyword.objects.get_or_create(name=keyword_name)
            keyword_objects.append(keyword)
            if created:
                self.stdout.write(self.style.SUCCESS(f'Created keyword: {keyword.name}'))
            else:
                self.stdout.write(self.style.SUCCESS(f'Keyword already exists: {keyword.name}'))

        # Create random items related to mobile phones
        for _ in range(100):
            try:
                unique_name = f"{fake.word().capitalize()} Mobile {random.randint(1, 10000)}"
                item = Item.objects.create(
                    name=unique_name,  # Ensure the item name is unique
                    subcategory=subcategory,
                    sku=fake.uuid4(),
                    stock=random.randint(1, 100),
                    price=round(random.uniform(100.00, 1500.00), 2),
                    discount=random.uniform(5, 20),
                    specification=fake.text(),
                    last_modified_by=random.choice(User.objects.all())
                )
                # Add all mobile phone-related keywords to each item
                item.keywords.set(keyword_objects)
                self.stdout.write(self.style.SUCCESS(f'Created item: {item.name}'))
            except:
                print("NO")

        self.stdout.write(self.style.SUCCESS('Successfully populated the database with 100 mobile phone-related items'))



