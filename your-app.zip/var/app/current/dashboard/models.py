from django.db import models
from django.contrib.auth.models import User
from django.utils.crypto import get_random_string
# Create your models here.
from django.db import models
from django.utils.crypto import get_random_string
from django.contrib.auth.models import User  # Import the User model
class Category(models.Model):
    name = models.CharField(max_length=255,unique=True)
    image = models.ImageField(upload_to='category_images/',null=True, blank=True)
    details = models.TextField(null=True, blank=True)
    discount = models.DecimalField(default=0,max_digits=5, decimal_places=2)  # Discount in percentage

    def __str__(self):
        return self.name

class Subcategory(models.Model):
    name = models.CharField(max_length=255,unique=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name='subcategory')
    details = models.TextField(null=True, blank=True)
    image = models.ImageField(upload_to='subcategory_images/',null=True, blank=True)
    discount = models.DecimalField(default=0,max_digits=5, decimal_places=2)

    def __str__(self):
        return self.name

class Keyword(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name
class Item(models.Model):
    name = models.CharField(max_length=255,unique=True)
    image1 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    image2 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    image3 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    video = models.FileField(upload_to='videos/', null=True, blank=True)  # Add this line
    subcategory = models.ForeignKey(Subcategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='items')
    sku = models.CharField(max_length=100, unique=True)
    stock = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(default=1,max_digits=5, decimal_places=2)  # Discount in percentage
    specification = models.TextField(null=True, blank=True)
    token = models.PositiveIntegerField(default=0)
    special_item_status = models.BooleanField(default=False)
    affiliate_token = models.CharField(max_length=255,null=True, blank=True)
    last_modified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)  # New field
    keywords = models.ManyToManyField(Keyword, related_name='items', blank=True)  # New field


    def __str__(self):
        return self.name

class ItemVariant(models.Model):
    item = models.ForeignKey(Item, related_name='variants', on_delete=models.CASCADE)
    color = models.CharField(max_length=50, blank=True, null=True)
    size = models.CharField(max_length=50, blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)

    def __str__(self):
        attributes = []
        if self.color:
            attributes.append(f"Color: {self.color}")
        if self.size:
            attributes.append(f"Size: {self.size}")
        return f"{self.item.name} - {' '.join(attributes)}"
class Affiliate(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    points = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username

class AffiliateLink(models.Model):
    affiliate = models.ForeignKey(Affiliate, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    unique_code = models.CharField(max_length=10, unique=True, default=get_random_string)
    created_at = models.DateTimeField(auto_now_add=True)

    def generate_link(self):
        return f"http://127.0.0.1:8000/api/share/{self.unique_code}/"

class Order(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    affiliate_link = models.ForeignKey(AffiliateLink, on_delete=models.SET_NULL, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    confirmed = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('dispatched', 'Dispatched'),
        ('cancelled', 'Cancelled'),
    ])
    created_at = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    region = models.CharField(max_length=100)
    def confirm_order(self):
        self.confirmed = True
        if self.affiliate_link:
            affiliate = self.affiliate_link.affiliate
            affiliate.points += self.item.price * 0.1  # Example: 10% of item price as points
            affiliate.save()
        self.save()

