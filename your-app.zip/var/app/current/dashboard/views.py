from .models import Category, Subcategory, Item
from .serializers import CategorySerializer, SubCategorySerializer, ItemSerializer
from rest_framework.permissions import IsAdminUser
from rest_framework import viewsets
from rest_framework.decorators import action
from .models import Affiliate, AffiliateLink, Item, Order
from .serializers import AffiliateLinkSerializer, OrderSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import AffiliateLink
from .serializers import ItemSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login
from django.middleware.csrf import get_token
from rest_framework.permissions import AllowAny
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from rest_framework import status
from django.db.models import Q
from fuzzywuzzy import process

from .models import Category
from .serializers import CategorySerializer
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework import status
from .models import Item, Keyword
from .serializers import ItemSerializer
from rest_framework.generics import CreateAPIView
from .serializers import KeywordSerializer
from rest_framework.pagination import PageNumberPagination

class ItemPagination(PageNumberPagination):
    page_size = 30  # Number of items per page

class AuthenticatedCheckView(APIView):
    # Disable authentication and permission checks for this view
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)  # Log the user in to create a session
            csrf_token = get_token(request)  # Get CSRF token
            sessionid = request.session.session_key  # Get session ID
            return Response({
                "status": "success",
                "statuscode":status.HTTP_200_OK,
                "csrf": csrf_token,
                "sessionid": sessionid
            }, status=status.HTTP_200_OK)
        else:
            return Response({"status": "fail"}, status=status.HTTP_401_UNAUTHORIZED)
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]


    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data, "statuscode": status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Category deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e), "statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset = Subcategory.objects.all()
    serializer_class = SubCategorySerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Subcategory deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)
class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [AllowAny]
    pagination_class = ItemPagination  # Apply pagination here

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success","statuscode":status.HTTP_204_NO_CONTENT,"message": "Item deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail","statuscode":status.HTTP_400_BAD_REQUEST, "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)

#Affilate code start from here

class AffiliateLinkViewSet(viewsets.ModelViewSet):
    queryset = AffiliateLink.objects.all()
    serializer_class = AffiliateLinkSerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=['post'])
    def create_link(self, request, pk=None):
        affiliate = get_object_or_404(Affiliate, user=request.user)
        item = get_object_or_404(Item, pk=pk)
        affiliate_link, created = AffiliateLink.objects.get_or_create(affiliate=affiliate, item=item)
        return Response(AffiliateLinkSerializer(affiliate_link).data)

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=['post'])
    def confirm(self, request, pk=None):
        order = get_object_or_404(Order, pk=pk)
        order.confirm_order()
        return Response(OrderSerializer(order).data)


class ShareItemView(APIView):
    permission_classes = [AllowAny]

    print(f"Received request for unique_code")

    def get(self, request, unique_code):
        print(f"Received request for unique_code: {unique_code}")
        # Fetch the AffiliateLink object using the unique_code
        affiliate_link = get_object_or_404(AffiliateLink, unique_code=unique_code)
        # Get the associated Item
        item = affiliate_link.item
        # Serialize the item data
        serializer = ItemSerializer(item)
        # Return the item details
        return Response(serializer.data, status=status.HTTP_200_OK)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from django.db.models import Sum, Count
from django.utils.timezone import now
from .models import Order, Category, Item
from .serializers import AdminInsightsSerializer, SalesByCategorySerializer, SalesByRegionSerializer, TopSellingProductSerializer, MonthWiseSalesSerializer, YearSalesSerializer

class AdminInsightsAPIView(APIView):
    permission_classes = [AllowAny]


    def get(self, request):
        today = now().date()

        # Total Sales Today
        total_sales_today = Order.objects.filter(created_at__date=today, confirmed=True).aggregate(total=Sum('item__price'))['total'] or 0

        # Sales by Category
        sales_by_category = Category.objects.annotate(total_sales=Sum('subcategory__items__order__item__price')).values('name', 'total_sales')
        sales_by_category_list = SalesByCategorySerializer(sales_by_category, many=True).data
        sales_by_category_count = len(sales_by_category_list)

        # Sales by Region
        sales_by_region = Order.objects.filter(confirmed=True).values('region').annotate(total_sales=Sum('item__price'))
        sales_by_region_list = SalesByRegionSerializer(sales_by_region, many=True).data
        sales_by_region_count = len(sales_by_region_list)

        # Top Selling Products
        top_selling_products = Item.objects.annotate(sales_count=Count('order')).order_by('-sales_count')[:5]
        top_selling_products_list = TopSellingProductSerializer(top_selling_products, many=True).data
        top_selling_products_count = len(top_selling_products_list)

        # Orders Insights
        dispatched_orders = Order.objects.filter(status='dispatched')
        dispatched_orders_list = [str(order.id) for order in dispatched_orders]
        dispatched_orders_count = dispatched_orders.count()

        pending_orders = Order.objects.filter(status='pending')
        pending_orders_list = [str(order.id) for order in pending_orders]
        pending_orders_count = pending_orders.count()

        cancelled_orders = Order.objects.filter(status='cancelled')
        cancelled_orders_list = [str(order.id) for order in cancelled_orders]
        cancelled_orders_count = cancelled_orders.count()

        # Low Stock Alerts
        low_stock_alerts = Item.objects.filter(stock__lte=10)
        low_stock_alerts_list = [item.name for item in low_stock_alerts]
        low_stock_alerts_count = low_stock_alerts.count()

        # Month-wise Sales
        month_wise_sales = Order.objects.filter(confirmed=True).dates('created_at', 'month').annotate(total_sales=Sum('item__price'))
        month_wise_sales_list = MonthWiseSalesSerializer(month_wise_sales, many=True).data
        month_wise_sales_count = len(month_wise_sales_list)

        # Year Sales
        year_sales = Order.objects.filter(confirmed=True).dates('created_at', 'year').annotate(total_sales=Sum('item__price'))
        year_sales_list = YearSalesSerializer(year_sales, many=True).data
        year_sales_count = len(year_sales_list)

        data = {
            'total_sales_today': total_sales_today,
            'sales_by_category': sales_by_category_list,
            'sales_by_category_count': sales_by_category_count,
            'sales_by_region': sales_by_region_list,
            'sales_by_region_count': sales_by_region_count,
            'top_selling_products': top_selling_products_list,
            'top_selling_products_count': top_selling_products_count,
            'dispatched_orders': dispatched_orders_list,
            'dispatched_orders_count': dispatched_orders_count,
            'pending_orders': pending_orders_list,
            'pending_orders_count': pending_orders_count,
            'cancelled_orders': cancelled_orders_list,
            'cancelled_orders_count': cancelled_orders_count,
            'low_stock_alerts': low_stock_alerts_list,
            'low_stock_alerts_count': low_stock_alerts_count,
            'month_wise_sales': month_wise_sales_list,
            'month_wise_sales_count': month_wise_sales_count,
            'year_sales': year_sales_list,
            'year_sales_count': year_sales_count,
        }

        serializer = AdminInsightsSerializer(data)
        return Response(serializer.data)

class ItemSearchView(ListAPIView):
    serializer_class = ItemSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        query = self.request.query_params.get('q')
        if query:
            keywords = query.split()
            q_objects = Q()
            for keyword in keywords:
                # Perform fuzzy matching
                matching_keywords = Keyword.objects.all()
                best_match, score = process.extractOne(keyword, [kw.name for kw in matching_keywords])

                if score >= 70:  # Threshold for fuzzy match
                    q_objects |= Q(keywords__name__iexact=best_match)

            return Item.objects.filter(q_objects).distinct()

        return Item.objects.none()

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        if queryset.exists():
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({'detail': 'No items found matching the keywords.'}, status=status.HTTP_404_NOT_FOUND)
class KeywordCreateView(CreateAPIView):
    permission_classes = [AllowAny]
    queryset = Keyword.objects.all()
    serializer_class = KeywordSerializer