from rest_framework import serializers
from .models import Category, Subcategory, Item,Affiliate, AffiliateLink, Order,Keyword
from django.utils.crypto import get_random_string
from rest_framework import serializers
from .models import Item
from rest_framework import serializers
from .models import Category, Item, Order,ItemVariant


class ItemVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemVariant
        fields = ['id', 'color', 'size', 'price', 'stock']
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id','name', 'image','details','discount']

class SubCategorySerializer(serializers.ModelSerializer):
    category = serializers.SlugRelatedField(queryset=Category.objects.all(), slug_field='name')

    class Meta:
        model = Subcategory
        fields = ['id','name', 'category','details','image', 'discount']

class KeywordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Keyword
        fields = ['id', 'name']

    def create(self, validated_data):
        keyword, created = Keyword.objects.get_or_create(**validated_data)
        return keyword
class ItemSerializer(serializers.ModelSerializer):
    subcategory = serializers.SlugRelatedField(queryset=Subcategory.objects.all(), slug_field='name')
    variants = ItemVariantSerializer(many=True, read_only=True)

    # Use KeywordSerializer for nested serialization of keywords
    keywords = KeywordSerializer(many=True, read_only=True)
    keywords_input = serializers.ListField(
        child=serializers.CharField(max_length=255),
        write_only=True,
        required=False
    )
    variants_input = ItemVariantSerializer(many=True, write_only=True, required=False)

    class Meta:
        model = Item
        fields = [
            'id', 'name', 'image1', 'image2', 'image3', 'video', 'subcategory', 'sku',
            'stock', 'price', 'discount', 'specification', 'token', 'special_item_status',
            'affiliate_token', 'last_modified_by', 'keywords', 'keywords_input','variants','variants_input'
        ]

    def create(self, validated_data):
        keywords_data = validated_data.pop('keywords_input','')
        keywords_list = keywords_data.split(',')
        variants_data = validated_data.pop('variants_input', '')
        variants_list = variants_data.split(',')
        item = Item.objects.create(**validated_data)

        # Handle keywords
        for keyword_name in keywords_list:
            keyword, created = Keyword.objects.get_or_create(name=keyword_name.strip())
            item.keywords.add(keyword)

        # Handle variants
        for variant_data in variants_list:
            ItemVariant.objects.create(item=item, **variant_data)

        return item

    def update(self, instance, validated_data):
        keywords_data = validated_data.pop('keywords_input', None)
        variants_data = validated_data.pop('variants_input', None)
        keywords_list = keywords_data.split(',')
        variants_list = variants_data.split(',')
        # Update the item instance
        instance = super().update(instance, validated_data)

        # Handle keywords
        if keywords_data is not None:
            instance.keywords.clear()
            for keyword_name in keywords_list:
                keyword, created = Keyword.objects.get_or_create(name=keyword_name.strip())
                instance.keywords.add(keyword)

        # Handle variants
        if variants_data is not None:
            # Clear existing variants
            instance.variants.all().delete()
            for variant_data in variants_list:
                ItemVariant.objects.create(item=instance, **variant_data)

        return instance

class AffiliateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Affiliate
        fields = '__all__'

class AffiliateLinkSerializer(serializers.ModelSerializer):
    link = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = AffiliateLink
        fields = ['id','affiliate', 'item', 'unique_code', 'created_at', 'link']
        read_only_fields = ['unique_code', 'created_at']

    def get_link(self, obj):
        return obj.generate_link()

    def create(self, validated_data):
        # The unique_code will be automatically generated, so we remove it from validated_data if present
        unique_code = validated_data.get('unique_code', None)
        if unique_code is None:
            validated_data['unique_code'] = get_random_string(length=10)

        return super().create(validated_data)

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'


class SalesByCategorySerializer(serializers.ModelSerializer):
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        model = Category
        fields = ['name', 'total_sales']

class SalesByRegionSerializer(serializers.Serializer):
    region = serializers.CharField()
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class TopSellingProductSerializer(serializers.ModelSerializer):
    sales_count = serializers.IntegerField()

    class Meta:
        model = Item
        fields = ['name', 'sales_count']

class MonthWiseSalesSerializer(serializers.Serializer):
    month = serializers.DateField()
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class YearSalesSerializer(serializers.Serializer):
    year = serializers.DateField()
    total_sales = serializers.DecimalField(max_digits=10, decimal_places=2)

class AdminInsightsSerializer(serializers.Serializer):
    total_sales_today = serializers.DecimalField(max_digits=10, decimal_places=2)
    sales_by_category = serializers.ListField(child=SalesByCategorySerializer())
    sales_by_category_count = serializers.IntegerField()

    sales_by_region = serializers.ListField(child=SalesByRegionSerializer())
    sales_by_region_count = serializers.IntegerField()

    top_selling_products = serializers.ListField(child=TopSellingProductSerializer())
    top_selling_products_count = serializers.IntegerField()

    dispatched_orders = serializers.ListField(child=serializers.CharField())
    dispatched_orders_count = serializers.IntegerField()

    pending_orders = serializers.ListField(child=serializers.CharField())
    pending_orders_count = serializers.IntegerField()

    cancelled_orders = serializers.ListField(child=serializers.CharField())
    cancelled_orders_count = serializers.IntegerField()

    low_stock_alerts = serializers.ListField(child=serializers.CharField())
    low_stock_alerts_count = serializers.IntegerField()

    month_wise_sales = serializers.ListField(child=MonthWiseSalesSerializer())
    month_wise_sales_count = serializers.IntegerField()

    year_sales = serializers.ListField(child=YearSalesSerializer())
    year_sales_count = serializers.IntegerField()
