# project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from dashboard.views import ShareItemView,AuthenticatedCheckView,AdminInsightsAPIView,ItemSearchView,KeywordCreateView
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/check-authenticated/', AuthenticatedCheckView.as_view(), name='check-authenticated'),
    path('api/share/<str:unique_code>/', ShareItemView.as_view(), name='share-item'),
    path('api/', include('dashboard.urls')),
    path('insights/', AdminInsightsAPIView.as_view(), name='admin-insights'),
    path('items/search/', ItemSearchView.as_view(), name='item-search'),
    path('keywords/', KeywordCreateView.as_view(), name='keyword-create'),


    # Include the URLs from the app

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
