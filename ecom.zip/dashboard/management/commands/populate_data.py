# # from django.core.management.base import BaseCommand
# # from dashboard.models import Category, Subcategory, Item, Keyword
# # from django.contrib.auth.models import User
# # from faker import Faker
# # import random
# # import os
# # import shutil
# # from django.conf import settings
# #
# # class Command(BaseCommand):
# #     help = 'Generate random users, categories, subcategories, items, and keywords related to mobile phones'
# #
# #     def handle(self, *args, **kwargs):
# #         # Initialize Faker
# #         fake = Faker()
# #
# #         # Directory containing images for upload
# #         image_directory = r'C:\Users\SearchGrand\Downloads\forupload'
# #         # List of all image files in the directory
# #         image_files = [f for f in os.listdir(image_directory) if os.path.isfile(os.path.join(image_directory, f))]
# #
# #         # Create random users
# #         for _ in range(10):
# #             user = User.objects.create_user(
# #                 username=fake.user_name(),
# #                 email=fake.email(),
# #                 password='password123',
# #                 first_name=fake.first_name(),
# #                 last_name=fake.last_name()
# #             )
# #             self.stdout.write(self.style.SUCCESS(f'Created user: {user.username}'))
# #
# #         # Create or get category
# #         category, created = Category.objects.get_or_create(
# #             name='Electronics',
# #             defaults={'details': 'All electronic items', 'discount': random.uniform(5, 15)}
# #         )
# #         if created:
# #             self.stdout.write(self.style.SUCCESS(f'Created category: {category.name}'))
# #         else:
# #             self.stdout.write(self.style.SUCCESS(f'Category already exists: {category.name}'))
# #
# #         # Generate up to 12 unique subcategory names
# #         subcategory_names = set()
# #         while len(subcategory_names) < 12:
# #             subcategory_names.add(fake.word().capitalize())
# #         subcategory_objects = []
# #
# #         # Create or get subcategories
# #         for name in subcategory_names:
# #             subcategory, created = Subcategory.objects.get_or_create(
# #                 name=name,
# #                 defaults={'category': category, 'details': fake.sentence(), 'discount': random.uniform(5, 10)}
# #             )
# #             subcategory_objects.append(subcategory)
# #             if created:
# #                 self.stdout.write(self.style.SUCCESS(f'Created subcategory: {subcategory.name}'))
# #             else:
# #                 self.stdout.write(self.style.SUCCESS(f'Subcategory already exists: {subcategory.name}'))
# #
# #         # Create or get keywords related to mobile phones
# #         keywords = [
# #             'Camera', 'RAM', 'Storage', 'Battery', 'Processor', 'Display', '5G', 'Wireless Charging', 'Dual SIM', 'Fingerprint Sensor'
# #         ]
# #
# #         keyword_objects = []
# #         for keyword_name in keywords:
# #             keyword, created = Keyword.objects.get_or_create(name=keyword_name)
# #             keyword_objects.append(keyword)
# #             if created:
# #                 self.stdout.write(self.style.SUCCESS(f'Created keyword: {keyword.name}'))
# #             else:
# #                 self.stdout.write(self.style.SUCCESS(f'Keyword already exists: {keyword.name}'))
# #
# #         # Create random items related to mobile phones
# #         for _ in range(100):
# #             try:
# #                 unique_name = f"{fake.word().capitalize()} Mobile {random.randint(1, 10000)}"
# #                 # Randomly select an image file from the directory
# #                 random_image_file = random.choice(image_files)
# #                 image_path = os.path.join(image_directory, random_image_file)
# #
# #                 # Extract base name for keyword
# #                 base_name = os.path.splitext(random_image_file)[0]
# #
# #                 # Create or get keyword for the image
# #                 image_keyword, created = Keyword.objects.get_or_create(name=base_name)
# #                 if created:
# #                     self.stdout.write(self.style.SUCCESS(f'Created keyword: {image_keyword.name}'))
# #                 else:
# #                     self.stdout.write(self.style.SUCCESS(f'Keyword already exists: {image_keyword.name}'))
# #
# #                 # Copy image file to Django's media folder
# #                 new_image_path = os.path.join(settings.MEDIA_ROOT, 'item_images', random_image_file)
# #                 os.makedirs(os.path.dirname(new_image_path), exist_ok=True)
# #                 shutil.copy(image_path, new_image_path)
# #
# #                 # Create the item
# #                 item = Item.objects.create(
# #                     name=unique_name,  # Ensure the item name is unique
# #                     subcategory=random.choice(subcategory_objects),  # Randomly assign one of the 12 subcategories
# #                     sku=fake.uuid4(),
# #                     stock=random.randint(1, 100),
# #                     price=round(random.uniform(100.00, 1500.00), 2),
# #                     discount=random.uniform(5, 20),
# #                     specification=fake.text(),
# #                     last_modified_by=random.choice(User.objects.all()),
# #                     image1=f'item_images/{random_image_file}',  # Assign the relative path to image1
# #                 )
# #
# #                 # Add all mobile phone-related keywords to each item
# #                 item.keywords.set([image_keyword])
# #                 self.stdout.write(self.style.SUCCESS(f'Created item: {item.name}'))
# #             except Exception as e:
# #                 self.stdout.write(self.style.ERROR(f'Failed to create item: {e}'))
# #
# #         self.stdout.write(self.style.SUCCESS('Successfully populated the database with 100 mobile phone-related items'))
# from django.core.management.base import BaseCommand
# from dashboard.models import Category, Subcategory, Item, Keyword
# from django.contrib.auth.models import User
# from faker import Faker
# import random
# import os
# import shutil
# from django.conf import settings
#
# class Command(BaseCommand):
#     help = 'Generate random users, categories, subcategories, items, and keywords related to mobile phones'
#
#     def handle(self, *args, **kwargs):
#         # Initialize Faker
#         fake = Faker()
#
#         # Directory containing images for categories
#         category_image_directory = r'C:\Users\SearchGrand\Downloads\data\Category'
#         # List of all image files in the directory
#         category_image_files = [f for f in os.listdir(category_image_directory) if os.path.isfile(os.path.join(category_image_directory, f))]
#
#         # Create categories from images
#         for image_file in category_image_files:
#             try:
#                 # Extract the category name from the image file name (excluding extension)
#                 category_name = os.path.splitext(image_file)[0]
#
#                 # Create or get the category
#                 category, created = Category.objects.get_or_create(
#                     name=category_name,
#                     defaults={'details': f'{category_name} category details'}  # Customize as needed
#                 )
#
#                 # If the category was newly created, assign the image to it
#                 if created:
#                     # Path to the image in the media folder
#                     new_image_path = os.path.join(settings.MEDIA_ROOT, 'category_images', image_file)
#                     os.makedirs(os.path.dirname(new_image_path), exist_ok=True)
#
#                     # Copy the image to Django's media folder
#                     shutil.copy(os.path.join(category_image_directory, image_file), new_image_path)
#
#                     # Assign the image path to the category's image field
#                     category.image = f'category_images/{image_file}'
#                     category.save()
#
#                     self.stdout.write(self.style.SUCCESS(f'Created category: {category.name} with image: {image_file}'))
#                 else:
#                     self.stdout.write(self.style.WARNING(f'Category already exists: {category.name}'))
#
#             except Exception as e:
#                 self.stdout.write(self.style.ERROR(f'Failed to create category {category_name}: {e}'))
#
#         # Directory containing subcategory folders
#         subcategory_directory = r'C:\Users\SearchGrand\Downloads\data\Subcategory'
#
#         # Create subcategories based on images inside the category-named folders
#         for category_name in os.listdir(subcategory_directory):
#             category_path = os.path.join(subcategory_directory, category_name)
#             if os.path.isdir(category_path):
#                 # Get the category or skip if it doesn't exist
#                 try:
#                     category = Category.objects.get(name=category_name)
#                 except Category.DoesNotExist:
#                     self.stdout.write(self.style.WARNING(f'Category {category_name} does not exist, skipping subcategories in this folder.'))
#                     continue
#
#                 # Process each image inside the category-named folder
#                 for image_file in os.listdir(category_path):
#                     if os.path.isfile(os.path.join(category_path, image_file)):
#                         try:
#                             # Extract the subcategory name from the image file name (excluding extension)
#                             subcategory_name = os.path.splitext(image_file)[0]
#
#                             # Create or get the subcategory
#                             subcategory, created = Subcategory.objects.get_or_create(
#                                 name=subcategory_name,
#                                 category=category,
#                                 defaults={'details': f'{subcategory_name} subcategory details'}  # Customize as needed
#                             )
#
#                             # If the subcategory was newly created, assign the image to it
#                             if created:
#                                 # Path to the image in the media folder
#                                 new_image_path = os.path.join(settings.MEDIA_ROOT, 'subcategory_images', image_file)
#                                 os.makedirs(os.path.dirname(new_image_path), exist_ok=True)
#
#                                 # Copy the image to Django's media folder
#                                 shutil.copy(os.path.join(category_path, image_file), new_image_path)
#
#                                 # Assign the image path to the subcategory's image field
#                                 subcategory.image = f'subcategory_images/{image_file}'
#                                 subcategory.save()
#
#                                 self.stdout.write(self.style.SUCCESS(f'Created subcategory: {subcategory.name} in category {category.name} with image: {image_file}'))
#                             else:
#                                 self.stdout.write(self.style.WARNING(f'Subcategory already exists: {subcategory.name} in category {category.name}'))
#
#                         except Exception as e:
#                             self.stdout.write(self.style.ERROR(f'Failed to create subcategory {subcategory_name} in category {category_name}: {e}'))
#
#         # Directory containing images for items
#         image_directory = r'C:\Users\SearchGrand\Downloads\forupload'
#         # List of all image files in the directory
#         image_files = [f for f in os.listdir(image_directory) if os.path.isfile(os.path.join(image_directory, f))]
#
#         # Create random users
#         for _ in range(10):
#             user = User.objects.create_user(
#                 username=fake.user_name(),
#                 email=fake.email(),
#                 password='password123',
#                 first_name=fake.first_name(),
#                 last_name=fake.last_name()
#             )
#             self.stdout.write(self.style.SUCCESS(f'Created user: {user.username}'))
#
#         # Create or get keywords related to mobile phones
#         keywords = [
#             'Camera', 'RAM', 'Storage', 'Battery', 'Processor', 'Display', '5G', 'Wireless Charging', 'Dual SIM', 'Fingerprint Sensor'
#         ]
#
#         keyword_objects = []
#         for keyword_name in keywords:
#             keyword, created = Keyword.objects.get_or_create(name=keyword_name)
#             keyword_objects.append(keyword)
#             if created:
#                 self.stdout.write(self.style.SUCCESS(f'Created keyword: {keyword.name}'))
#             else:
#                 self.stdout.write(self.style.SUCCESS(f'Keyword already exists: {keyword.name}'))
#
#         # Create random items related to mobile phones
#         subcategory_objects = Subcategory.objects.all()
#         for _ in range(100):
#             try:
#                 unique_name = f"{fake.word().capitalize()} Mobile {random.randint(1, 10000)}"
#                 # Randomly select an image file from the directory
#                 random_image_file = random.choice(image_files)
#                 image_path = os.path.join(image_directory, random_image_file)
#
#                 # Extract base name for keyword
#                 base_name = os.path.splitext(random_image_file)[0]
#
#                 # Create or get keyword for the image
#                 image_keyword, created = Keyword.objects.get_or_create(name=base_name)
#                 if created:
#                     self.stdout.write(self.style.SUCCESS(f'Created keyword: {image_keyword.name}'))
#                 else:
#                     self.stdout.write(self.style.SUCCESS(f'Keyword already exists: {image_keyword.name}'))
#
#                 # Copy image file to Django's media folder
#                 new_image_path = os.path.join(settings.MEDIA_ROOT, 'item_images', random_image_file)
#                 os.makedirs(os.path.dirname(new_image_path), exist_ok=True)
#                 shutil.copy(image_path, new_image_path)
#
#                 # Create the item
#                 item = Item.objects.create(
#                     name=unique_name,  # Ensure the item name is unique
#                     subcategory=random.choice(subcategory_objects),  # Randomly assign a subcategory
#                     sku=fake.uuid4(),
#                     stock=random.randint(1, 100),
#                     price=round(random.uniform(100.00, 1500.00), 2),
#                     discount=random.uniform(5, 20),
#                     specification=fake.text(),
#                     last_modified_by=random.choice(User.objects.all()),
#                     image1=f'item_images/{random_image_file}',  # Assign the relative path to image1
#                 )
#
#                 # Add all mobile phone-related keywords to each item
#                 item.keywords.set([image_keyword])
#                 self.stdout.write(self.style.SUCCESS(f'Created item: {item.name}'))
#             except Exception as e:
#                 self.stdout.write(self.style.ERROR(f'Failed to create item: {e}'))
#
#         self.stdout.write(self.style.SUCCESS('Successfully populated the database with categories, subcategories, and 100 mobile phone-related items'))
from django.core.management.base import BaseCommand
from dashboard.models import Category, Subcategory, Item, Keyword
from django.contrib.auth.models import User
from faker import Faker
import random
import os
import shutil
from django.conf import settings

class Command(BaseCommand):
    help = 'Generate random users, categories, subcategories, and items with associated images'

    def handle(self, *args, **kwargs):
        # Initialize Faker
        fake = Faker()

        # Directory containing images for categories
        category_image_directory = r'C:\Users\SearchGrand\Downloads\data\Category'
        # List of all image files in the directory
        category_image_files = [f for f in os.listdir(category_image_directory) if os.path.isfile(os.path.join(category_image_directory, f))]

        # Create categories from images
        for image_file in category_image_files:
            try:
                # Extract the category name from the image file name (excluding extension)
                category_name = os.path.splitext(image_file)[0]

                # Create or get the category
                category, created = Category.objects.get_or_create(
                    name=category_name,
                    defaults={'details': f'{category_name} category details'}  # Customize as needed
                )

                # If the category was newly created, assign the image to it
                if created:
                    # Path to the image in the media folder
                    new_image_path = os.path.join(settings.MEDIA_ROOT, 'category_images', image_file)
                    os.makedirs(os.path.dirname(new_image_path), exist_ok=True)

                    # Copy the image to Django's media folder
                    shutil.copy(os.path.join(category_image_directory, image_file), new_image_path)

                    # Assign the image path to the category's image field
                    category.image = f'category_images/{image_file}'
                    category.save()

                    self.stdout.write(self.style.SUCCESS(f'Created category: {category.name} with image: {image_file}'))
                else:
                    self.stdout.write(self.style.WARNING(f'Category already exists: {category.name}'))

            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Failed to create category {category_name}: {e}'))

        # Directory containing subcategory folders
        subcategory_directory = r'C:\Users\SearchGrand\Downloads\data\Subcategory'

        # Create subcategories and associate them with categories
        for category_folder in os.listdir(subcategory_directory):
            category_path = os.path.join(subcategory_directory, category_folder)

            if os.path.isdir(category_path):
                # Get or create the category
                category, _ = Category.objects.get_or_create(name=category_folder)

                # Process each image in the subcategory folder
                for image_file in os.listdir(category_path):
                    if os.path.isfile(os.path.join(category_path, image_file)):
                        try:
                            # Extract subcategory name from the image file name (excluding extension)
                            subcategory_name = os.path.splitext(image_file)[0]

                            # Create or get the subcategory
                            subcategory, created = Subcategory.objects.get_or_create(
                                name=subcategory_name,
                                category=category,
                                defaults={'details': f'{subcategory_name} subcategory details'}
                            )

                            # If the subcategory was newly created, assign the image to it
                            if created:
                                # Path to the image in the media folder
                                new_image_path = os.path.join(settings.MEDIA_ROOT, 'subcategory_images', image_file)
                                os.makedirs(os.path.dirname(new_image_path), exist_ok=True)

                                # Copy the image to Django's media folder
                                shutil.copy(os.path.join(category_path, image_file), new_image_path)

                                # Assign the image path to the subcategory's image field
                                subcategory.image = f'subcategory_images/{image_file}'
                                subcategory.save()

                                self.stdout.write(self.style.SUCCESS(f'Created subcategory: {subcategory.name} with image: {image_file}'))
                            else:
                                self.stdout.write(self.style.WARNING(f'Subcategory already exists: {subcategory.name}'))

                        except Exception as e:
                            self.stdout.write(self.style.ERROR(f'Failed to create subcategory {subcategory_name}: {e}'))

        # Directory containing items, with subcategory folders inside
        items_directory = r'C:\Users\SearchGrand\Downloads\data\Items'

        # Create items and associate them with subcategories
        for subcategory_folder in os.listdir(items_directory):
            subcategory_path = os.path.join(items_directory, subcategory_folder)

            if os.path.isdir(subcategory_path):
                # Get the corresponding subcategory
                try:
                    subcategory = Subcategory.objects.get(name=subcategory_folder)
                except Subcategory.DoesNotExist:
                    self.stdout.write(self.style.ERROR(f'Subcategory not found: {subcategory_folder}'))
                    continue

                # Process each image in the item folder
                for image_file in os.listdir(subcategory_path):
                    if os.path.isfile(os.path.join(subcategory_path, image_file)):
                        try:
                            # Extract item name from the image file name (excluding extension)
                            item_name = os.path.splitext(image_file)[0]

                            # Create the item
                            item, created = Item.objects.get_or_create(
                                name=item_name,
                                subcategory=subcategory,
                                defaults={
                                    'sku': fake.uuid4(),
                                    'stock': random.randint(1, 100),
                                    'price': round(random.uniform(100.00, 1500.00), 2),
                                    'discount': random.uniform(5, 20),
                                    'specification': fake.text(),
                                    'last_modified_by': random.choice(User.objects.all())
                                }
                            )

                            # If the item was newly created, assign the image to it
                            if created:
                                # Path to the image in the media folder
                                new_image_path = os.path.join(settings.MEDIA_ROOT, 'item_images', image_file)
                                os.makedirs(os.path.dirname(new_image_path), exist_ok=True)

                                # Copy the image to Django's media folder
                                shutil.copy(os.path.join(subcategory_path, image_file), new_image_path)

                                # Assign the image path to the item's image field
                                item.image1 = f'item_images/{image_file}'
                                item.save()

                                self.stdout.write(self.style.SUCCESS(f'Created item: {item.name} with image: {image_file}'))
                            else:
                                self.stdout.write(self.style.WARNING(f'Item already exists: {item.name}'))

                        except Exception as e:
                            self.stdout.write(self.style.ERROR(f'Failed to create item {item_name}: {e}'))

        self.stdout.write(self.style.SUCCESS('Successfully populated the database with categories, subcategories, and items from specified directories'))
