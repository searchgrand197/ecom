To search view subcategory (change Electronics only)
http://127.0.0.1:8000/api/subfind/?subcategory_name=Electronics
To search Keyword(change 32mp only)
http://127.0.0.1:8000/items/search/?q=32mp